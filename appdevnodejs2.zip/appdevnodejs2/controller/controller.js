const main = {
    index:(req, res) =>{
        res.render('index');
    }
}

module.exports = main;